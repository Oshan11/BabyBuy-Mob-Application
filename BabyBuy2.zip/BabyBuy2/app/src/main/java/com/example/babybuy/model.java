package com.example.babybuy;

public class model
{
    String name,description,price,purl;
    model()
    {

    }
    public model(String name, String description, String price, String purl) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.purl = purl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String course) {
        this.description = course;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPurl() {
        return purl;
    }

    public void setPurl(String purl) {
        this.purl = purl;
    }
}