package com.example.babybuy;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;

public class ViewDataActivity extends AppCompatActivity {

    TextView txtName,txtDesc,txtPrice;
    ImageView image;
    Uri url;
    EditText phoneNo;
    Button btnSend;

    String name,desc, price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_data);

        txtName = findViewById(R.id.viewName);
        txtDesc  = findViewById(R.id.courseholder);
        txtPrice  = findViewById(R.id.emailholder);
        image = findViewById(R.id.imagegholder);

        name = getIntent().getExtras().getString("Name");
        desc = getIntent().getExtras().getString("description");
        price = getIntent().getExtras().getString("price");

        txtName.setText("Item Name : "+name);
        txtDesc.setText("Item Description : "+desc);
        txtPrice.setText("Item Price : "+ price);


        String url= getIntent().getExtras().getString("image");
        Glide.with(getApplicationContext()).load(url).into(image);


        phoneNo = findViewById(R.id.phoneNo);
        btnSend =findViewById(R.id.btnSend);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(ViewDataActivity.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED){
                    sendSMS();
                }
                else{
                    ActivityCompat.requestPermissions(ViewDataActivity.this,new String[]{Manifest.permission.SEND_SMS},100);
                }
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED){
            sendSMS();
        }
        else{
            Toast.makeText(this,"Permission Denied!!!",Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSMS() {

        String phone = phoneNo.getText().toString();
        String name = txtName.getText().toString();
        String description = txtDesc.getText().toString();
        String price = txtPrice.getText().toString();

        String message = "Item Name : "+ name + "\n"+"Item Description : "+description + "\n" + "Item Price : "+ price;

        if(!phone.isEmpty() && !name.isEmpty()){
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone,null,message,null,null);
            Toast.makeText(this,"SMS send successfully!!!",Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(this,"Please enter phone number!!!",Toast.LENGTH_SHORT).show();
        }
    }
}