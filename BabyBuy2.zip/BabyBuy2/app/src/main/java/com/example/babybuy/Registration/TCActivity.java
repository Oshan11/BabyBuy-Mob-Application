package com.example.babybuy.Registration;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babybuy.R;

public class TCActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tcactivity);
    }
}