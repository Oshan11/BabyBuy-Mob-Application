package com.example.babybuy;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
