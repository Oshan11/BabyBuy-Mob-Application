package com.example.babybuy;

public class VariableClass {
    public static String id;
    public static String category;
    public static int count=0;
    public static String bn;
}
