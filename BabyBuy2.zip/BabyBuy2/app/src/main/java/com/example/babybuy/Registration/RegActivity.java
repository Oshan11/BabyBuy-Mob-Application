package com.example.babybuy.Registration;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babybuy.MainActivity;
import com.example.babybuy.Model.Parent;
import com.example.babybuy.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegActivity extends AppCompatActivity {
    private EditText parentId,firstName,surname,email,password,confirmPassword;
    private Button register;
    private TextView viewTC;
    private CheckBox readTick;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);

        databaseReference = FirebaseDatabase.getInstance().getReference("Parents");
        parentId = (EditText)findViewById(R.id.id);
        firstName = (EditText)findViewById(R.id.first_name);
        surname = (EditText)findViewById(R.id.surname);
        email= (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.password);
        confirmPassword = (EditText)findViewById(R.id.confirm_password);
        register = (Button) findViewById(R.id.register);
        readTick = (CheckBox)findViewById(R.id.checked);
        viewTC = (TextView)findViewById(R.id.tc);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addParents();
            }
        });
        viewTC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openActivity3();
            }
        });

    }
    public void openActivity3(){
        Intent intent = new Intent(this,TCActivity.class);
        startActivity(intent);

    }


    private void addParents() {
        String parentID = parentId.getText().toString();
        String FirstName = firstName.getText().toString();
        String Surname = surname.getText().toString();
        String Email = email.getText().toString();
        String Password = password.getText().toString();
        String ConfirmPassword = confirmPassword.getText().toString();

        if (!TextUtils.isEmpty(parentID) && !TextUtils.isEmpty(ConfirmPassword) && !TextUtils.isEmpty(Password) && !TextUtils.isEmpty(Email) && !TextUtils.isEmpty(Surname) && !TextUtils.isEmpty(FirstName) ){
            if ((ConfirmPassword).equals(Password)){
                if (readTick.isChecked()){
                    String id = databaseReference.push().getKey();
                    Parent student = new Parent(parentID,FirstName,Surname,Email,Password);
                    databaseReference.child(parentID).setValue(student);
                    parentId.setText("");
                    firstName.setText("");
                    surname.setText("");
                    email.setText("");
                    password.setText("");
                    confirmPassword.setText("");
                    Toast.makeText(RegActivity.this,"Registration Successful",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                }else {
                    Toast.makeText(RegActivity.this,"Please read terms and conditions",Toast.LENGTH_LONG).show();
                }


            }else {
                Toast.makeText(RegActivity.this,"Password and confirm password not match",Toast.LENGTH_LONG).show();
            }

        }else{
            Toast.makeText(RegActivity.this,"Complete the details",Toast.LENGTH_LONG).show();
        }
    }
}