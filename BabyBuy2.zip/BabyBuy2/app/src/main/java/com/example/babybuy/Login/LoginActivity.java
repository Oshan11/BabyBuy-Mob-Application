package com.example.babybuy.Login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babybuy.MainActivity;
import com.example.babybuy.Model.Parent;
import com.example.babybuy.R;
import com.example.babybuy.Registration.RegActivity;
import com.example.babybuy.VariableClass;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {
    int count;
    private Button button;
    private TextView txt1,txt2;
    private EditText x,y;
    DatabaseReference databaseReference,mRef;
    Parent parent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        button = (Button) findViewById(R.id.login);
        txt1 = (TextView) findViewById(R.id.new_register);

        x = (EditText) findViewById(R.id.id);

        y = (EditText) findViewById(R.id.password);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        mRef = databaseReference.child("Parents").getRef();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mRef.addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String xxx = x.getText().toString();
                        String yyy = y.getText().toString();
                        try{
                            for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                                String data1 = dataSnapshot.child(xxx).child("password").getValue().toString();
                                if(yyy.equals(data1)){
                                    Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_LONG).show();
                                    VariableClass.id = x.getText().toString();
                                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                    startActivity(intent);


                                }
                                else{
                                    Toast.makeText(LoginActivity.this,"Login Fail",Toast.LENGTH_LONG).show();
                                }
                            }
                        }catch(Exception ex){
                            Toast.makeText(LoginActivity.this,"Login Fail",Toast.LENGTH_LONG).show();
                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });

        txt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });
    }

    private void openActivity2() {
        Intent intent = new Intent(this, RegActivity.class);
        startActivity(intent);
    }
}